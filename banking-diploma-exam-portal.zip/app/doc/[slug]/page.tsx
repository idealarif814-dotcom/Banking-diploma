import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Download } from 'lucide-react'
import { Breadcrumbs } from '@/components/breadcrumbs'
import { formatBnNumber, toBnDigits } from '@/lib/bn'
import { getAllDocuments, getDocumentBySlug } from '@/lib/data'

type Props = { params: Promise<{ slug: string }> }

export async function generateStaticParams() {
  return (await getAllDocuments()).map((d) => ({ slug: d.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const doc = await getDocumentBySlug(slug)
  if (!doc) return {}
  return {
    title: doc.title,
    description: doc.description,
    keywords: [doc.exam, doc.subject, String(doc.year), ...doc.tags],
    alternates: { canonical: `/doc/${doc.slug}` },
    openGraph: { title: doc.title, description: doc.description, images: [doc.thumbnail] },
  }
}

export default async function DocumentPage({ params }: Props) {
  const { slug } = await params
  const doc = await getDocumentBySlug(slug)
  if (!doc) notFound()

  const facts = [
    { label: 'পরীক্ষা', value: doc.exam },
    { label: 'সাল', value: toBnDigits(doc.year) },
    { label: 'পৃষ্ঠা', value: `${toBnDigits(doc.pages)}টি` },
    { label: 'ভাষা', value: doc.language },
    { label: 'উৎস', value: doc.source },
    { label: 'ডাউনলোড', value: `${formatBnNumber(doc.downloads)} বার` },
  ]

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Breadcrumbs
        items={[
          { label: doc.exam, href: `/exam/${doc.exam_slug}` },
          { label: doc.subject, href: `/exam/${doc.exam_slug}/${doc.subject_slug}` },
          { label: toBnDigits(doc.year) },
        ]}
      />

      <article className="grid gap-8 md:grid-cols-[240px_1fr]">
        <div className="relative mx-auto aspect-[3/4] w-48 overflow-hidden rounded-xl border bg-muted shadow-sm md:w-full">
          <Image
            src={doc.thumbnail}
            alt={`${doc.title} এর প্রচ্ছদ`}
            fill
            priority
            sizes="(min-width: 768px) 240px, 192px"
            className="object-cover"
          />
        </div>

        <div className="flex flex-col gap-5">
          <h1 className="text-2xl font-bold leading-snug text-balance sm:text-3xl">{doc.title}</h1>

          <dl className="grid grid-cols-2 gap-3 rounded-xl border bg-card p-4 sm:grid-cols-3">
            {facts.map((f) => (
              <div key={f.label}>
                <dt className="text-xs text-muted-foreground">{f.label}</dt>
                <dd className="font-semibold">{f.value}</dd>
              </div>
            ))}
          </dl>

          <p className="leading-relaxed text-pretty">{doc.description}</p>

          {doc.tags.length > 0 ? (
            <ul className="flex flex-wrap gap-2" aria-label="ট্যাগ">
              {doc.tags.map((tag) => (
                <li key={tag}>
                  <Link
                    href={`/search?q=${encodeURIComponent(tag)}`}
                    className="inline-block rounded-full bg-secondary px-3 py-1 text-sm text-secondary-foreground hover:bg-secondary/70"
                  >
                    {'#'}
                    {tag}
                  </Link>
                </li>
              ))}
            </ul>
          ) : null}

          <Link
            href={`/download/${doc.slug}`}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 text-base font-semibold text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 sm:w-fit"
          >
            <Download className="size-5" aria-hidden="true" />
            ডাউনলোড
          </Link>
        </div>
      </article>
    </div>
  )
}
