import type { Metadata } from 'next'
import { DocumentGrid } from '@/components/document-card'
import { Pagination } from '@/components/pagination'
import { SearchForm } from '@/components/search-form'
import { toBnDigits } from '@/lib/bn'
import { searchDocuments } from '@/lib/data'

type Props = { searchParams: Promise<{ q?: string | string[]; page?: string | string[] }> }

const PAGE_SIZE = 10

function first(value: string | string[] | undefined): string {
  return (Array.isArray(value) ? value[0] : value) ?? ''
}

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const q = first((await searchParams).q).trim()
  return {
    title: q ? `"${q}" এর সার্চ ফলাফল` : 'প্রশ্নপত্র খুঁজুন',
    description: q
      ? `"${q}" সম্পর্কিত ব্যাংকিং ডিপ্লোমা পরীক্ষার প্রশ্ন ও উত্তর PDF।`
      : 'শিরোনাম, বিষয়, সাল বা ট্যাগ দিয়ে ব্যাংকিং ডিপ্লোমা পরীক্ষার প্রশ্নপত্র খুঁজুন।',
    robots: { index: !q, follow: true },
  }
}

export default async function SearchPage({ searchParams }: Props) {
  const params = await searchParams
  const q = first(params.q).trim().slice(0, 100)
  const page = Number.parseInt(first(params.page), 10) || 1
  const result = await searchDocuments(q, page, PAGE_SIZE)

  const buildHref = (p: number) => {
    const sp = new URLSearchParams({ q })
    if (p > 1) sp.set('page', String(p))
    return `/search?${sp.toString()}`
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="mb-4 text-2xl font-bold">প্রশ্নপত্র খুঁজুন</h1>
      <SearchForm defaultValue={q} autoFocus={!q} />

      <section aria-live="polite" className="mt-8">
        {!q ? (
          <p className="text-muted-foreground">
            উদাহরণ: “হিসাববিজ্ঞান”, “AIIB ২০২৩”, “আইন”
          </p>
        ) : result.total === 0 ? (
          <div className="rounded-xl border border-dashed bg-card p-8 text-center">
            <p className="font-semibold">
              {'"'}
              {q}
              {'"'} এর জন্য কোনো ফলাফল পাওয়া যায়নি
            </p>
            <p className="mt-1 text-sm text-muted-foreground">অন্য শব্দ বা সাল দিয়ে চেষ্টা করুন।</p>
          </div>
        ) : (
          <>
            <p className="mb-4 text-sm text-muted-foreground">
              {toBnDigits(result.total)}টি ফলাফল
              {result.totalPages > 1
                ? ` · পেজ ${toBnDigits(result.page)}/${toBnDigits(result.totalPages)}`
                : ''}
            </p>
            <DocumentGrid docs={result.items} />
            <Pagination page={result.page} totalPages={result.totalPages} buildHref={buildHref} />
          </>
        )}
      </section>
    </div>
  )
}
