import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { Breadcrumbs } from '@/components/breadcrumbs'
import { DocumentGrid } from '@/components/document-card'
import { toBnDigits } from '@/lib/bn'
import { getDocumentsBySubject, getExams, getSubject, getSubjectsForExam, groupByYear } from '@/lib/data'

type Props = { params: Promise<{ examSlug: string; subjectSlug: string }> }

export async function generateStaticParams() {
  const exams = await getExams()
  const nested = await Promise.all(
    exams.map(async (e) =>
      (await getSubjectsForExam(e.exam_slug)).map((s) => ({
        examSlug: e.exam_slug,
        subjectSlug: s.subject_slug,
      })),
    ),
  )
  return nested.flat()
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { examSlug, subjectSlug } = await params
  const subject = await getSubject(examSlug, subjectSlug)
  if (!subject) return {}
  return {
    title: `${subject.exam} ${subject.subject} — প্রশ্ন ও উত্তর PDF`,
    description: `${subject.exam} পরীক্ষার ${subject.subject} বিষয়ের ${toBnDigits(subject.years.length)}টি সালের প্রশ্নপত্র ও উত্তর PDF, সাল অনুযায়ী সাজানো।`,
    alternates: { canonical: `/exam/${examSlug}/${subjectSlug}` },
  }
}

export default async function SubjectPage({ params }: Props) {
  const { examSlug, subjectSlug } = await params
  const subject = await getSubject(examSlug, subjectSlug)
  if (!subject) notFound()

  const byYear = groupByYear(await getDocumentsBySubject(examSlug, subjectSlug))

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Breadcrumbs
        items={[{ label: subject.exam, href: `/exam/${examSlug}` }, { label: subject.subject }]}
      />
      <h1 className="text-3xl font-bold text-balance">
        {subject.exam}: {subject.subject}
      </h1>
      <p className="mt-2 text-muted-foreground">
        {toBnDigits(subject.documentCount)}টি PDF · {toBnDigits(subject.years.length)}টি সাল
      </p>

      {byYear.map(({ year, documents }) => (
        <section key={year} aria-labelledby={`year-${year}`} className="mt-8">
          <h2
            id={`year-${year}`}
            className="mb-3 flex items-center gap-3 text-lg font-bold after:h-px after:flex-1 after:bg-border"
          >
            {toBnDigits(year)}
          </h2>
          <DocumentGrid docs={documents} />
        </section>
      ))}
    </div>
  )
}
