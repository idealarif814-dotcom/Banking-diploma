import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronRight } from 'lucide-react'
import { Breadcrumbs } from '@/components/breadcrumbs'
import { DocumentGrid } from '@/components/document-card'
import { toBnDigits } from '@/lib/bn'
import {
  getDocumentsByExam,
  getExamBySlug,
  getExams,
  getSubjectsForExam,
  groupByYear,
} from '@/lib/data'

type Props = { params: Promise<{ examSlug: string }> }

export async function generateStaticParams() {
  return (await getExams()).map((e) => ({ examSlug: e.exam_slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { examSlug } = await params
  const exam = await getExamBySlug(examSlug)
  if (!exam) return {}
  return {
    title: `${exam.exam} প্রশ্ন ও উত্তর PDF`,
    description: `${exam.exam} পরীক্ষার ${toBnDigits(exam.subjectCount)}টি বিষয়ের বিগত সালের প্রশ্নপত্র ও উত্তর — সাল অনুযায়ী সাজানো PDF ডাউনলোড করুন।`,
    alternates: { canonical: `/exam/${exam.exam_slug}` },
  }
}

export default async function ExamPage({ params }: Props) {
  const { examSlug } = await params
  const exam = await getExamBySlug(examSlug)
  if (!exam) notFound()

  const [subjects, docs] = await Promise.all([
    getSubjectsForExam(examSlug),
    getDocumentsByExam(examSlug),
  ])
  const byYear = groupByYear(docs)

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Breadcrumbs items={[{ label: exam.exam }]} />
      <h1 className="text-3xl font-bold">{exam.exam} প্রশ্ন ও উত্তর</h1>
      <p className="mt-2 text-muted-foreground">
        {toBnDigits(exam.subjectCount)}টি বিষয় · {toBnDigits(exam.documentCount)}টি PDF
      </p>

      <section aria-labelledby="subjects-heading" className="mt-8">
        <h2 id="subjects-heading" className="mb-3 text-xl font-bold">
          বিষয় তালিকা
        </h2>
        <ul className="divide-y overflow-hidden rounded-xl border bg-card">
          {subjects.map((s) => (
            <li key={s.subject_slug}>
              <Link
                href={`/exam/${exam.exam_slug}/${s.subject_slug}`}
                className="flex items-center justify-between gap-3 px-4 py-3.5 transition-colors hover:bg-muted"
              >
                <span className="font-medium">{s.subject}</span>
                <span className="flex shrink-0 items-center gap-1 text-sm text-muted-foreground">
                  {toBnDigits(s.documentCount)}টি PDF
                  <ChevronRight className="size-4" aria-hidden="true" />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {byYear.map(({ year, documents }) => (
        <section key={year} aria-labelledby={`year-${year}`} className="mt-10">
          <h2 id={`year-${year}`} className="mb-3 text-xl font-bold">
            {toBnDigits(year)} সালের PDF
          </h2>
          <DocumentGrid docs={documents} />
        </section>
      ))}
    </div>
  )
}
