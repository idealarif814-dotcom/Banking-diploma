import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { FileText } from 'lucide-react'
import { AdSlot } from '@/components/ad-slot'
import { Breadcrumbs } from '@/components/breadcrumbs'
import { DownloadButton } from '@/components/download-button'
import { toBnDigits } from '@/lib/bn'
import { getDocumentBySlug } from '@/lib/data'
import { checkPdfFile } from '@/lib/files'

type Props = { params: Promise<{ slug: string }> }

// File availability is checked per request so newly added PDFs appear without a rebuild.
export const dynamic = 'force-dynamic'

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const doc = await getDocumentBySlug(slug)
  if (!doc) return {}
  return {
    title: `ডাউনলোড: ${doc.title}`,
    description: `${doc.title} — ${toBnDigits(doc.pages)} পৃষ্ঠার PDF বিনামূল্যে ডাউনলোড করুন।`,
    alternates: { canonical: `/download/${doc.slug}` },
    robots: { index: false, follow: true },
  }
}

export default async function DownloadPage({ params }: Props) {
  const { slug } = await params
  const doc = await getDocumentBySlug(slug)
  if (!doc) notFound()

  const file = await checkPdfFile(doc.file_path)

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <Breadcrumbs
        items={[{ label: doc.exam, href: `/exam/${doc.exam_slug}` }, { label: 'ডাউনলোড' }]}
      />

      <AdSlot slotId="download-top" format="banner" className="mb-6" />

      <section className="flex flex-col items-center gap-5 rounded-2xl border bg-card px-4 py-8 text-center sm:px-8">
        <span className="flex size-14 items-center justify-center rounded-2xl bg-secondary text-primary">
          <FileText className="size-7" aria-hidden="true" />
        </span>
        <div className="flex flex-col gap-1.5">
          <h1 className="text-xl font-bold leading-snug text-balance sm:text-2xl">{doc.title}</h1>
          <p className="text-sm text-muted-foreground">
            {doc.subject} · {toBnDigits(doc.year)} · {toBnDigits(doc.pages)} পৃষ্ঠা
          </p>
        </div>
        <DownloadButton slug={doc.slug} fileName={`${doc.slug}.pdf`} available={file.ok} />
        <Link href={`/doc/${doc.slug}`} className="text-sm text-primary underline-offset-4 hover:underline">
          বিস্তারিত দেখুন
        </Link>
      </section>

      <AdSlot slotId="download-bottom" format="rectangle" className="mt-6" />
    </div>
  )
}
